#!/usr/bin/env python
# coding: utf-8

# In[171]:


import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# In[172]:


dataset = np.genfromtxt("hw04_data_set.csv", skip_header=True, delimiter = ",")

x_train = np.zeros(150)
y_train = np.zeros(150)
x_test = np.zeros(122)
y_test = np.zeros(122)

x_train[:] = dataset[:150,0]
y_train[:] = dataset[:150,1]
x_test[:] = dataset[150:272,0]
y_test[:] = dataset[150:272,1]


# In[173]:


xmax = max(x_train)
train_shape = x_train.shape[0]
bin_width = 0.37
origin = 1.5
left_borders = np.arange(origin, xmax, bin_width)
right_borders = np.arange(origin + bin_width, xmax + bin_width, bin_width)


# In[174]:


regressogram = np.asarray([np.sum(((left_borders[b] < x_train) & (x_train <= right_borders[b])) * y_train) / np.sum((left_borders[b] < x_train) & (x_train <= right_borders[b])) for b in range(len(left_borders))])
plt.figure(figsize = (10, 6))
plt.plot(x_train, y_train, "b.", markersize = 10, label = "training")
plt.plot(x_test, y_test, "r.", markersize = 10, label = "test")

for b in range(len(left_borders)):
    plt.plot([left_borders[b], right_borders[b]], [regressogram[b], regressogram[b]], "k-")
for b in range(len(left_borders) - 1):
    plt.plot([right_borders[b], right_borders[b]], [regressogram[b], regressogram[b + 1]], "k-") 

plt.legend(loc='upper left')
plt.ylabel("Waiting time to next eruption (min)")
plt.xlabel("Eruption time (min)")
plt.show()


# In[175]:


def rmse1(datatest):
    rmse = 0
    for i in range(0,len(datatest)):
        for j in range(0,len(left_borders)):
            if(left_borders[j] < datatest[i] and datatest[i] < right_borders[j]):
                error = (y_test[i] - regressogram[int((datatest[i]-origin)/bin_width)])**2
                rmse += error
    return np.sqrt(rmse / len(datatest))

print("Regressogram => RMSE is", rmse1(x_test), "when h is", bin_width)


# In[176]:


data_interval = np.arange(origin, xmax, 0.001)
def mean_s(index):
    sum = 0
    counter = 0
    for i in range(train_shape):
        if(np.abs((data_interval[index]-x_train[i])/bin_width) < 0.5):
            sum +=  y_train[i]
            counter += 1
    return sum/counter


mean_s = np.array([mean_s(i) for i in range(data_interval.shape[0])])

plt.figure(figsize = (10, 6))
plt.plot(x_train, y_train, "b.", markersize = 10, label = "training")
plt.plot(x_test, y_test, "r.", markersize = 10, label = "test")
plt.plot(data_interval, mean_s, "k-")

plt.legend(loc='upper left')
plt.ylabel("Waiting time to next eruption (min)")
plt.xlabel("Eruption time (min)")
plt.show()


# In[177]:


def rmse2(datatest, array):  
    error = [(y_test[i] - array[int((datatest[i]-origin)*1000)])**2 for i in range(len(datatest))]
    return np.sqrt(np.sum(error) / len(datatest))

print("Running Mean Smoother => RMSE is", rmse2(x_test, mean_s), "when h is", bin_width)


# In[178]:


def K(u):
    return 1 / np.sqrt(2 * np.pi) * np.exp(-0.5 * u ** 2)

def kernel_s(index):
    sum = 0
    counter = 0
    for i in range(0,len(x_train)):
        x = (data_interval[index] - x_train[i]) / bin_width
        counter += K((data_interval[index] - x_train[i]) / bin_width)
        sum += (K((data_interval[index] - x_train[i]) / bin_width) * y_train[i])       
    return sum / counter

kernel_s = np.array([kernel_s(i) for i in range(data_interval.shape[0])])


# In[179]:


plt.figure(figsize = (10, 6))
plt.plot(x_train, y_train, "b.", markersize = 10, label = "training")
plt.plot(x_test, y_test, "r.", markersize = 10, label = "test")
plt.plot(data_interval, kernel_s, "k-")

plt.legend(loc='upper left')
plt.ylabel("Waiting time to next eruption (min)")
plt.xlabel("Eruption time (min)")
plt.show()


# In[180]:


print("Kernel Smoother => RMSE is", rmse2(x_test, kernel_s), "when h is", bin_width)


# In[ ]:




